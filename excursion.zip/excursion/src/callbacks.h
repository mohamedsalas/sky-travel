#include <gtk/gtk.h>


void on_confirmer_rex_clicked (GtkWidget *objet_graphique,gpointer user_data);

void on_retour_reserve_client_excursion_clicked (GtkWidget *objet,gpointer  user_data);

void on_retour_panier_client_excursion_clicked (GtkWidget *objet,gpointer  user_data);

void on_actualiser_panier_clicked   (GtkWidget  *objet,gpointer user_data);

void on_modifier_reservation_excursion_clicked (GtkWidget *button,gpointer user_data);

void on_supprimer_rex_clicked      (GtkWidget *objet_graphique,gpointer user_data);

void on_reserver_excursion_client_clicked   (GtkWidget *objet,gpointer user_data);

void on_rechercher_client_excursion_clicked (GtkWidget  *objet_graphique,gpointer  user_data);

void on_afficher_client_excursion_clicked (GtkWidget  *objet_graphique,gpointer  user_data);

void on_panier_excursion_clicked  (GtkWidget *objet,gpointer user_data);

void on_confirmer_rex_clicked (GtkWidget *objet_graphique,gpointer user_data);
